import os
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (QAction, QDialog, QVBoxLayout, QLabel, 
                                 QLineEdit, QPushButton, QMessageBox, QFormLayout, QGroupBox)
from qgis.gui import QgsMapLayerComboBox, QgsMapToolEmitPoint
from qgis.core import QgsMapLayerProxyModel, QgsRectangle, QgsFeatureRequest

# --- 1. หน้าต่างสำหรับการกรอกชื่อหมุดหลักเขตใหม่ (POINT) ---
class EditBndNameDialog(QDialog):
    def __init__(self, layer, features, parent=None):
        super(EditBndNameDialog, self).__init__(parent)
        self.setWindowTitle("บันทึกชื่อหมุดหลักเขตใหม่")
        self.setMinimumWidth(350)
        self.layer = layer
        self.features = features
        
        self.setStyleSheet("""
            QLabel { font-size: 12pt; font-weight: bold; }
            QLineEdit { font-size: 14pt; padding: 5px; }
            QPushButton { font-size: 12pt; font-weight: bold; padding: 8px; background-color: #28a745; color: white; border-radius: 5px; }
        """)

        layout = QVBoxLayout()
        layout.addWidget(QLabel(f"แก้ไขข้อมูลหมุดจำนวน {len(features)} จุด"))
        
        self.name_input = QLineEdit()
        
        # ดึงค่าเก่ามาแสดงเป็นค่าเริ่มต้น (ถ้ามี)
        idx = self.layer.fields().indexOf("BND_NAME")
        if idx != -1 and len(self.features) > 0:
            current_val = self.features[0].attribute(idx)
            if current_val:
                self.name_input.setText(str(current_val))
                
        self.name_input.setPlaceholderText("ระบุชื่อ BND_NAME ใหม่...")
        layout.addWidget(self.name_input)
        
        self.btn_save = QPushButton("Save (บันทึก)")
        self.btn_save.clicked.connect(self.save_data)
        layout.addWidget(self.btn_save)
        
        self.setLayout(layout)

    def save_data(self):
        new_name = self.name_input.text().strip()
        idx = self.layer.fields().indexOf("BND_NAME")
        if idx == -1:
            QMessageBox.critical(self, "ข้อผิดพลาด", "ไม่พบคอลัมน์ 'BND_NAME' ใน Layer นี้")
            return

        # บันทึกข้อมูล
        for f in self.features:
            self.layer.changeAttributeValue(f.id(), idx, new_name)
        
        # ถ้าระบบเปิด Edit อยู่ ให้ผู้ใช้เป็นคนกด Save ข้อมูลเองภายหลังเพื่อตรวจสอบความถูกต้อง
        QMessageBox.information(self, "สำเร็จ", "อัปเดตชื่อหมุดหลักเขตเรียบร้อยแล้ว (อย่าลืมกด Save Layer บน QGIS)")
        self.accept()

# --- 2. หน้าต่างสำหรับแก้ไข Attribute หลายฟิลด์ (POINT และ POLYGON) ---
class EditAttributesDialog(QDialog):
    def __init__(self, point_layer, poly_layer, parent=None):
        super(EditAttributesDialog, self).__init__(parent)
        self.setWindowTitle("แก้ไข Attribute (UTM & LANDNO)")
        self.setMinimumWidth(400)
        self.point_layer = point_layer
        self.poly_layer = poly_layer
        
        self.fields_to_edit = ["UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMSCALE", "UTMMAP4", "LANDNO"]
        self.inputs = {}

        self.setStyleSheet("""
            QLabel { font-size: 11pt; font-weight: bold; }
            QLineEdit { font-size: 12pt; padding: 5px; }
            QPushButton { font-size: 12pt; font-weight: bold; padding: 8px; background-color: #17a2b8; color: white; border-radius: 5px; }
        """)

        main_layout = QVBoxLayout()
        form_group = QGroupBox("ระบุข้อมูลที่ต้องการแก้ไข")
        form_layout = QFormLayout()

        # ดึงค่าเก่าจาก Polygon ตัวแรกมาแสดง (เพื่อความสะดวกไม่ต้องพิมพ์ใหม่ทั้งหมด)
        sample_feature = None
        if self.poly_layer:
            for f in self.poly_layer.getFeatures():
                sample_feature = f
                break

        for field in self.fields_to_edit:
            line_edit = QLineEdit()
            if sample_feature:
                idx = self.poly_layer.fields().indexOf(field)
                if idx != -1:
                    val = sample_feature.attribute(idx)
                    if val:
                        line_edit.setText(str(val))
            
            self.inputs[field] = line_edit
            form_layout.addRow(QLabel(field + ":"), line_edit)

        form_group.setLayout(form_layout)
        main_layout.addWidget(form_group)

        self.btn_save = QPushButton("บันทึกการแก้ไขลงทั้ง 2 Layer")
        self.btn_save.clicked.connect(self.save_attributes)
        main_layout.addWidget(self.btn_save)

        self.setLayout(main_layout)

    def save_attributes(self):
        layers_to_process = [l for l in [self.point_layer, self.poly_layer] if l is not None]
        
        for layer in layers_to_process:
            if not layer.isEditable():
                layer.startEditing()
                
            for field_name, input_widget in self.inputs.items():
                new_value = input_widget.text().strip()
                if not new_value: 
                    continue # ข้ามช่องที่ไม่ได้กรอก
                    
                field_idx = layer.fields().indexOf(field_name)
                if field_idx != -1:
                    for feature in layer.getFeatures():
                        layer.changeAttributeValue(feature.id(), field_idx, new_value)
        
        QMessageBox.information(self, "สำเร็จ", "อัปเดตข้อมูล Attributes เรียบร้อยแล้ว")
        self.accept()

# --- 3. เครื่องมือเมาส์สำหรับคลิกเลือกหมุดบนแผนที่ ---
class PointSelectTool(QgsMapToolEmitPoint):
    def __init__(self, canvas, layer, parent_dialog):
        super(PointSelectTool, self).__init__(canvas)
        self.canvas = canvas
        self.layer = layer
        self.parent_dialog = parent_dialog
        self.setCursor(Qt.CrossCursor)

    def canvasReleaseEvent(self, e):
        point = self.toMapCoordinates(e.pos())
        # สร้างขอบเขตพื้นที่รอบๆ จุดที่คลิก เผื่อคลิกไม่ตรงจุดเป๊ะๆ
        tol = self.canvas.mapUnitsPerPixel() * 10
        rect = QgsRectangle(point.x() - tol, point.y() - tol, point.x() + tol, point.y() + tol)
        
        request = QgsFeatureRequest().setFilterRect(rect)
        features = [f for f in self.layer.getFeatures(request)]
        
        if features:
            dlg = EditBndNameDialog(self.layer, features, self.parent_dialog)
            dlg.exec_()
        else:
            self.parent_dialog.iface.messageBar().pushMessage("แจ้งเตือน", "ไม่พบหมุดหลักเขตบริเวณที่คลิก", level=1, duration=3)
            
        # คืนค่าเครื่องมือกลับเป็นปกติหลังจากใช้งานเสร็จ
        self.canvas.unsetMapTool(self)

# --- 4. หน้าต่างเครื่องมือหลัก ---
class PathFilterTool(QDialog):
    def __init__(self, iface, parent=None):
        super(PathFilterTool, self).__init__(parent)
        self.iface = iface
        self.edit_tool = None # เก็บค่ายึดเครื่องมือเมาส์ไว้ ป้องกันขยะจากหน่วยความจำลบทิ้ง
        self.setWindowTitle("PATH Filter & Edit Tool")
        self.setMinimumWidth(500)
        
        self.setStyleSheet("""
            QDialog { background-color: #f5f5f5; }
            QLabel { font-size: 14pt; font-weight: bold; color: #333; margin-top: 10px; }
            QLineEdit { font-size: 16pt; padding: 10px; border: 2px solid #ccc; border-radius: 5px; background: white; }
            QComboBox { font-size: 14pt; padding: 8px; min-height: 40px; }
            QPushButton { font-size: 14pt; font-weight: bold; padding: 12px; border-radius: 6px; }
        """)

        layout = QVBoxLayout()

        layout.addWidget(QLabel("1. ระบุค่าที่ต้องการค้นหา (PATH):"))
        self.search_input = QLineEdit()
        layout.addWidget(self.search_input)

        layout.addWidget(QLabel("2. เลือก Layer (POINT):"))
        self.point_combo = QgsMapLayerComboBox()
        self.point_combo.setFilters(QgsMapLayerProxyModel.PointLayer)
        layout.addWidget(self.point_combo)

        layout.addWidget(QLabel("3. เลือก Layer (POLYGON):"))
        self.poly_combo = QgsMapLayerComboBox()
        self.poly_combo.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        layout.addWidget(self.poly_combo)

        self.btn_filter = QPushButton("เริ่ม Filter ข้อมูล (ซูมอัตโนมัติ)")
        self.btn_filter.setStyleSheet("background-color: #007bff; color: white; margin-top: 15px;")
        self.btn_filter.clicked.connect(self.apply_filter_and_zoom)
        layout.addWidget(self.btn_filter)

        self.btn_edit_point = QPushButton("แก้ไข ชื่อหมุดหลักเขต")
        self.btn_edit_point.setStyleSheet("background-color: #ffc107; color: black;")
        self.btn_edit_point.clicked.connect(self.activate_edit_point_tool)
        layout.addWidget(self.btn_edit_point)

        self.btn_edit_attr = QPushButton("แก้ไข Attribute (UTM & LANDNO)")
        self.btn_edit_attr.setStyleSheet("background-color: #17a2b8; color: white;")
        self.btn_edit_attr.clicked.connect(self.open_edit_attributes)
        layout.addWidget(self.btn_edit_attr)

        self.btn_clear = QPushButton("แสดงข้อมูลทั้งหมด (Clear)")
        self.btn_clear.setStyleSheet("background-color: #6c757d; color: white; margin-top: 15px;")
        self.btn_clear.clicked.connect(self.clear_filter)
        layout.addWidget(self.btn_clear)

        self.setLayout(layout)

    def apply_filter_and_zoom(self):
        search_val = self.search_input.text().strip()
        point_layer = self.point_combo.currentLayer()
        poly_layer = self.poly_combo.currentLayer()

        if not search_val:
            return

        query = f"\"PATH\" = '{search_val}'"
        
        combined_extent = QgsRectangle()
        combined_extent.setMinimal() # แก้ไข Error: 'QgsRectangle' object has no attribute 'setToNull'
        has_data = False
        
        for layer in [point_layer, poly_layer]:
            if layer:
                layer.setSubsetString(query)
                layer.updateExtents()
                ext = layer.extent()
                if not ext.isEmpty():
                    combined_extent.combineExtentWith(ext)
                    has_data = True

        if has_data:
            canvas = self.iface.mapCanvas()
            combined_extent.scale(1.1)
            canvas.setExtent(combined_extent)
            canvas.refresh()

    def activate_edit_point_tool(self):
        point_layer = self.point_combo.currentLayer()
        if not point_layer:
            QMessageBox.warning(self, "แจ้งเตือน", "กรุณาเลือก Layer POINT ก่อนใช้งานเครื่องมือนี้")
            return
            
        # บังคับเปิด Edit Mode ของ Layer POINT ทันที
        if not point_layer.isEditable():
            point_layer.startEditing()
            self.iface.messageBar().pushMessage("สถานะ", "เปิดโหมด Edit เรียบร้อยแล้ว", level=0, duration=3)

        canvas = self.iface.mapCanvas()
        # นำเข้า Class เครื่องมือคลิกมาใส่ในตัวแปรระดับ Class ของหน้าต่างนี้ (แก้บั๊ก Cursor ไม่เปลี่ยน)
        self.edit_tool = PointSelectTool(canvas, point_layer, self)
        canvas.setMapTool(self.edit_tool)
        self.iface.messageBar().pushMessage("สถานะ", "คลิกบริเวณหมุดหลักเขตบนแผนที่เพื่อแก้ไข", level=0, duration=5)

    def open_edit_attributes(self):
        point_layer = self.point_combo.currentLayer()
        poly_layer = self.poly_combo.currentLayer()
        
        if not point_layer and not poly_layer:
            QMessageBox.warning(self, "แจ้งเตือน", "กรุณาเลือก Layer ก่อนใช้งาน")
            return
            
        dlg = EditAttributesDialog(point_layer, poly_layer, self)
        dlg.exec_()

    def clear_filter(self):
        for combo in [self.point_combo, self.poly_combo]:
            layer = combo.currentLayer()
            if layer:
                layer.setSubsetString("")
                layer.updateExtents()

# --- 5. ส่วนการจัดการตัวปลั๊กอิน ---
class PathFilterPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        self.action = QAction(icon, "Path Filter & Edit Tool", self.iface.mainWindow())
        self.action.triggered.connect(self.run)

        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToVectorMenu("Land Dept Tools", self.action)

    def unload(self):
        self.iface.removePluginVectorMenu("Land Dept Tools", self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        self.dlg = PathFilterTool(self.iface, self.iface.mainWindow())
        self.dlg.show()