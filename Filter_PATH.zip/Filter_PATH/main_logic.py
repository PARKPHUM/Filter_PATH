import os
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (QAction, QDialog, QVBoxLayout, QLabel, 
                                 QLineEdit, QPushButton, QMessageBox)
from qgis.gui import QgsMapLayerComboBox, QgsMapToolEmitPoint
from qgis.core import QgsMapLayerProxyModel, QgsRectangle, QgsFeatureRequest

# --- 1. หน้าต่างสำหรับการกรอกชื่อหมุดหลักเขตใหม่ ---
class EditBndNameDialog(QDialog):
    def __init__(self, layer, features, parent=None):
        super(EditBndNameDialog, self).__init__(parent)
        self.setWindowTitle("บันทึกชื่อหมุดหลักเขตใหม่")
        self.setMinimumWidth(300)
        self.layer = layer
        self.features = features
        
        self.setStyleSheet("""
            QLabel { font-size: 12pt; font-weight: bold; }
            QLineEdit { font-size: 14pt; padding: 5px; }
            QPushButton { font-size: 12pt; font-weight: bold; padding: 8px; background-color: #28a745; color: white; border-radius: 5px; }
        """)

        layout = QVBoxLayout()
        layout.addWidget(QLabel(f"แก้ไขข้อมูลหมุดจำนวน {len(features)} จุด"))
        
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("ระบุชื่อ BND_NAME ใหม่...")
        layout.addWidget(self.name_input)
        
        self.btn_save = QPushButton("Save (บันทึก)")
        self.btn_save.clicked.connect(self.save_data)
        layout.addWidget(self.btn_save)
        
        self.setLayout(layout)

    def save_data(self):
        new_name = self.name_input.text().strip()
        if not new_name:
            QMessageBox.warning(self, "แจ้งเตือน", "กรุณากรอกชื่อหมุดหลักเขต")
            return

        # ตรวจสอบว่ามีคอลัมน์ BND_NAME หรือไม่
        idx = self.layer.fields().indexOf("BND_NAME")
        if idx == -1:
            QMessageBox.critical(self, "ข้อผิดพลาด", "ไม่พบคอลัมน์ 'BND_NAME' ใน Layer นี้")
            return

        # เริ่มต้นการแก้ไข (Start Editing) และบันทึก
        self.layer.startEditing()
        for f in self.features:
            self.layer.changeAttributeValue(f.id(), idx, new_name)
        self.layer.commitChanges()
        
        QMessageBox.information(self, "สำเร็จ", "อัปเดตชื่อหมุดหลักเขตเรียบร้อยแล้ว")
        self.accept()

# --- 2. เครื่องมือเมาส์สำหรับคลิกเลือกหมุดบนแผนที่ ---
class PointSelectTool(QgsMapToolEmitPoint):
    def __init__(self, canvas, layer, parent_dialog):
        super(PointSelectTool, self).__init__(canvas)
        self.canvas = canvas
        self.layer = layer
        self.parent_dialog = parent_dialog
        # เปลี่ยน Cursor เป็นรูปกากบาท (Crosshair)
        self.setCursor(Qt.CrossCursor)

    def canvasReleaseEvent(self, e):
        # ดึงพิกัดที่คลิก
        point = self.toMapCoordinates(e.pos())
        
        # สร้างขอบเขตพื้นที่รอบๆ จุดที่คลิก (Tolerance) เผื่อคลิกไม่โดนเป๊ะๆ
        tol = self.canvas.mapUnitsPerPixel() * 10
        rect = QgsRectangle(point.x() - tol, point.y() - tol, point.x() + tol, point.y() + tol)
        
        # ค้นหาข้อมูล POINT ที่อยู่ในรัศมีการคลิก (รองรับจุดที่ซ้อนทับกัน)
        request = QgsFeatureRequest().setFilterRect(rect)
        features = [f for f in self.layer.getFeatures(request)]
        
        if features:
            # เรียกหน้าต่างแก้ไข Attribute
            dlg = EditBndNameDialog(self.layer, features, self.parent_dialog)
            dlg.exec_()
        else:
            self.parent_dialog.iface.messageBar().pushMessage("แจ้งเตือน", "ไม่พบหมุดหลักเขตบริเวณที่คลิก", level=1, duration=3)
            
        # คืนค่าเครื่องมือกลับเป็นปกติหลังจากแก้ไขเสร็จ
        self.canvas.unsetMapTool(self)

# --- 3. หน้าต่างเครื่องมือหลัก ---
class PathFilterTool(QDialog):
    def __init__(self, iface, parent=None):
        super(PathFilterTool, self).__init__(parent)
        self.iface = iface
        self.setWindowTitle("PATH Filter & Edit Tool")
        self.setMinimumWidth(500)
        
        self.setStyleSheet("""
            QDialog { background-color: #f5f5f5; }
            QLabel { font-size: 14pt; font-weight: bold; color: #333; margin-top: 10px; }
            QLineEdit { font-size: 16pt; padding: 10px; border: 2px solid #ccc; border-radius: 5px; background: white; }
            QComboBox { font-size: 14pt; padding: 8px; min-height: 40px; }
            QPushButton { font-size: 14pt; font-weight: bold; padding: 12px; border-radius: 6px; }
        """)

        layout = QVBoxLayout()

        layout.addWidget(QLabel("1. ระบุค่าที่ต้องการค้นหา (PATH):"))
        self.search_input = QLineEdit()
        layout.addWidget(self.search_input)

        layout.addWidget(QLabel("2. เลือก Layer (POINT):"))
        self.point_combo = QgsMapLayerComboBox()
        self.point_combo.setFilters(QgsMapLayerProxyModel.PointLayer)
        layout.addWidget(self.point_combo)

        layout.addWidget(QLabel("3. เลือก Layer (POLYGON):"))
        self.poly_combo = QgsMapLayerComboBox()
        self.poly_combo.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        layout.addWidget(self.poly_combo)

        self.btn_filter = QPushButton("เริ่ม Filter ข้อมูล")
        self.btn_filter.setStyleSheet("background-color: #007bff; color: white; margin-top: 20px;")
        self.btn_filter.clicked.connect(self.apply_filter)
        layout.addWidget(self.btn_filter)

        # เพิ่มปุ่มแก้ไขชื่อหมุดหลักเขต
        self.btn_edit_point = QPushButton("แก้ไข ชื่อหมุดหลักเขต")
        self.btn_edit_point.setStyleSheet("background-color: #ffc107; color: black;")
        self.btn_edit_point.clicked.connect(self.activate_edit_tool)
        layout.addWidget(self.btn_edit_point)

        self.btn_clear = QPushButton("แสดงข้อมูลทั้งหมด (Clear)")
        self.btn_clear.setStyleSheet("background-color: #6c757d; color: white; margin-top: 20px;")
        self.btn_clear.clicked.connect(self.clear_filter)
        layout.addWidget(self.btn_clear)

        self.setLayout(layout)

    def apply_filter(self):
        search_val = self.search_input.text().strip()
        point_layer = self.point_combo.currentLayer()
        poly_layer = self.poly_combo.currentLayer()

        if not search_val:
            return

        query = f"\"PATH\" = '{search_val}'"
        
        # เตรียมตัวแปรสำหรับรวม Extent เพื่อ Zoom
        combined_extent = QgsRectangle()
        combined_extent.setMinimal()
        has_data = False
        
        for layer in [point_layer, poly_layer]:
            if layer:
                layer.setSubsetString(query)
                # ดึงขอบเขตของข้อมูลหลัง Filter
                layer.updateExtents()
                ext = layer.extent()
                if not ext.isEmpty():
                    combined_extent.combineExtentWith(ext)
                    has_data = True

        # ซูมไปยัง Layer ที่ถูก Filter
        if has_data:
            canvas = self.iface.mapCanvas()
            # ขยายขอบเขตออกไปอีก 10% เพื่อไม่ให้ชิดขอบจอเกินไป
            combined_extent.scale(1.1)
            canvas.setExtent(combined_extent)
            canvas.refresh()

    def activate_edit_tool(self):
        point_layer = self.point_combo.currentLayer()
        if not point_layer:
            QMessageBox.warning(self, "แจ้งเตือน", "กรุณาเลือก Layer POINT ก่อนใช้งานเครื่องมือนี้")
            return
            
        canvas = self.iface.mapCanvas()
        # เปิดใช้งานเครื่องมือคลิก
        tool = PointSelectTool(canvas, point_layer, self)
        canvas.setMapTool(tool)
        self.iface.messageBar().pushMessage("สถานะ", "คลิกบริเวณหมุดหลักเขตบนแผนที่เพื่อแก้ไข", level=0, duration=5)

    def clear_filter(self):
        for combo in [self.point_combo, self.poly_combo]:
            layer = combo.currentLayer()
            if layer:
                layer.setSubsetString("")

# --- 4. ส่วนการจัดการตัวปลั๊กอิน ---
class PathFilterPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        self.action = QAction(icon, "Path Filter & Edit Tool", self.iface.mainWindow())
        self.action.triggered.connect(self.run)

        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToVectorMenu("Land Dept Tools", self.action)

    def unload(self):
        self.iface.removePluginVectorMenu("Land Dept Tools", self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        # ส่ง self.iface เข้าไปด้วย
        self.dlg = PathFilterTool(self.iface, self.iface.mainWindow())
        self.dlg.show()