import os
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon, QFont
from qgis.PyQt.QtWidgets import QAction, QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton
from qgis.gui import QgsMapLayerComboBox
from qgis.core import QgsMapLayerProxyModel

# --- 1. ส่วนหน้าต่างเครื่องมือ (UI) ---
class PathFilterTool(QDialog):
    def __init__(self, parent=None):
        super(PathFilterTool, self).__init__(parent)
        self.setWindowTitle("PATH Filter - Department of Lands")
        self.setMinimumWidth(500)
        
        # ตั้งค่า Font พื้นฐานสำหรับทั้ง Dialog (ขนาดใหญ่ขึ้น)
        self.setStyleSheet("""
            QDialog { background-color: #f5f5f5; }
            QLabel { font-size: 14pt; font-weight: bold; color: #333; margin-top: 10px; }
            QLineEdit { font-size: 16pt; padding: 10px; border: 2px solid #ccc; border-radius: 5px; background: white; }
            QComboBox { font-size: 14pt; padding: 8px; min-height: 40px; }
            QPushButton { font-size: 14pt; font-weight: bold; padding: 12px; border-radius: 6px; }
        """)

        layout = QVBoxLayout()

        # 1. ช่องกรอกค่าค้นหา
        layout.addWidget(QLabel("1. ระบุค่าที่ต้องการค้นหา (PATH):"))
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("เช่น /folder/data/2026...")
        layout.addWidget(self.search_input)

        # 2. ช่องเลือก Layer POINT
        layout.addWidget(QLabel("2. เลือก Layer ประเภท POINT:"))
        self.point_combo = QgsMapLayerComboBox()
        self.point_combo.setFilters(QgsMapLayerProxyModel.PointLayer)
        layout.addWidget(self.point_combo)

        # 3. ช่องเลือก Layer POLYGON
        layout.addWidget(QLabel("3. เลือก Layer ประเภท POLYGON:"))
        self.poly_combo = QgsMapLayerComboBox()
        self.poly_combo.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        layout.addWidget(self.poly_combo)

        # 4. ปุ่มเริ่ม Filter (สีน้ำเงิน)
        self.btn_filter = QPushButton("เริ่ม Filter ข้อมูล")
        self.btn_filter.setStyleSheet("background-color: #007bff; color: white; margin-top: 20px;")
        self.btn_filter.clicked.connect(self.apply_filter)
        layout.addWidget(self.btn_filter)

        # 5. ปุ่มล้างค่า (สีเทาเข้ม)
        self.btn_clear = QPushButton("แสดงข้อมูลทั้งหมด (Clear)")
        self.btn_clear.setStyleSheet("background-color: #6c757d; color: white;")
        self.btn_clear.clicked.connect(self.clear_filter)
        layout.addWidget(self.btn_clear)

        self.setLayout(layout)

    def apply_filter(self):
        search_val = self.search_input.text().strip()
        point_layer = self.point_combo.currentLayer()
        poly_layer = self.poly_combo.currentLayer()

        if not search_val:
            return

        query = f"\"PATH\" = '{search_val}'"
        
        for layer in [point_layer, poly_layer]:
            if layer:
                layer.setSubsetString(query)

    def clear_filter(self):
        for combo in [self.point_combo, self.poly_combo]:
            layer = combo.currentLayer()
            if layer:
                layer.setSubsetString("")

# --- 2. ส่วนการจัดการตัวปลั๊กอิน (Plugin Infrastructure) ---
class PathFilterPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None

    def initGui(self):
        # สร้าง Icon (ถ้าไม่มีไฟล์ icon.png จะใช้ icon มาตรฐานของระบบแทน)
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        if not os.path.exists(icon_path):
            icon = QIcon() # สามารถใส่ path icon อื่นได้ที่นี่
        else:
            icon = QIcon(icon_path)

        # สร้าง Shortcut บน Toolbar
        self.action = QAction(icon, "Path Filter Tool (Large)", self.iface.mainWindow())
        self.action.triggered.connect(self.run)

        # เพิ่มลงใน Toolbar และเมนูหลัก
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToVectorMenu("Land Dept Tools", self.action)

    def unload(self):
        # ลบไอคอนออกเมื่อปิดปลั๊กอิน
        self.iface.removePluginVectorMenu("Land Dept Tools", self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        self.dlg = PathFilterTool(self.iface.mainWindow())
        self.dlg.show()