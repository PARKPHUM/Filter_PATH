import os
from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (QAction, QDialog, QVBoxLayout, QHBoxLayout, QLabel, 
                             QLineEdit, QPushButton, QTableWidget, QTableWidgetItem, QMessageBox)
from qgis.gui import QgsMapLayerComboBox, QgsMapToolIdentify, QgsMapToolEmitPoint
from qgis.core import QgsProject, QgsMapLayerProxyModel, QgsRectangle, QgsFeatureRequest

# --- 1. หน้าต่างสำหรับแก้ไขชื่อหมุด (Edit Attribute Dialog) ---
class EditBndNameDialog(QDialog):
    def __init__(self, layer, features, parent=None):
        super().__init__(parent)
        self.layer = layer
        self.features = features
        self.setWindowTitle("แก้ไขชื่อหมุดหลักเขต (BND_NAME)")
        self.setMinimumWidth(400)
        
        layout = QVBoxLayout()
        self.table = QTableWidget(len(features), 2)
        self.table.setHorizontalHeaderLabels(["Feature ID", "BND_NAME"])
        
        for i, feat in enumerate(features):
            self.table.setItem(i, 0, QTableWidgetItem(str(feat.id())))
            self.table.setItem(i, 1, QTableWidgetItem(str(feat['BND_NAME'])))
            
        layout.addWidget(QLabel(f"พบข้อมูล {len(features)} รายการ ในบริเวณที่เลือก:"))
        layout.addWidget(self.table)
        
        self.btn_save = QPushButton("บันทึกข้อมูล (Save)")
        self.btn_save.setStyleSheet("background-color: #28a745; color: white; font-weight: bold; padding: 10px;")
        self.btn_save.clicked.connect(self.save_data)
        layout.addWidget(self.btn_save)
        
        self.setLayout(layout)

    def save_data(self):
        self.layer.startEditing()
        for i in range(self.table.rowCount()):
            f_id = int(self.table.item(i, 0).text())
            new_name = self.table.item(i, 1).text()
            self.layer.changeAttributeValue(f_id, self.layer.fields().indexFromName('BND_NAME'), new_name)
        
        if self.layer.commitChanges():
            QMessageBox.information(self, "สำเร็จ", "อัปเดตข้อมูลเรียบร้อยแล้ว")
            self.accept()
        else:
            QMessageBox.critical(self, "ผิดพลาด", "ไม่สามารถบันทึกข้อมูลได้")

# --- 2. เครื่องมือคลิกบนแผนที่ (Map Tool) ---
class PointSelectTool(QgsMapToolIdentify):
    def __init__(self, canvas, layer, parent_dlg):
        super().__init__(canvas)
        self.canvas = canvas
        self.layer = layer
        self.parent_dlg = parent_dlg

    def canvasReleaseEvent(self, event):
        # ค้นหา Feature ในระยะที่คลิก (Tolerance)
        found_features = self.identifyLayer(event.x(), event.y(), self.layer, self.IdentifyMode.TopDownAll)
        
        if found_features:
            feats = [f.mFeature for f in found_features]
            edit_dlg = EditBndNameDialog(self.layer, feats, self.parent_dlg)
            edit_dlg.exec_()
        else:
            QMessageBox.warning(self.parent_dlg, "ไม่พบข้อมูล", "ไม่พบหมุดหลักเขตในบริเวณที่คลิก")
        
        # คืนค่า Cursor กลับเป็นปกติหลังจากเลือกเสร็จ (ถ้าต้องการ)
        self.canvas.unsetMapTool(self)

# --- 3. หน้าต่างหลักของปลั๊กอิน ---
class PathFilterTool(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("PATH Filter & Editor")
        self.setMinimumWidth(500)
        
        # UI Styles (Large Font)
        self.setStyleSheet("""
            QLabel { font-size: 13pt; font-weight: bold; margin-top: 8px; }
            QLineEdit { font-size: 14pt; padding: 8px; }
            QComboBox { font-size: 13pt; min-height: 35px; }
            QPushButton { font-size: 13pt; font-weight: bold; padding: 10px; border-radius: 5px; }
        """)

        layout = QVBoxLayout()

        # ส่วนที่ 1: เลือก Layer และค่า Filter
        layout.addWidget(QLabel("เลือก Layer (POINT):"))
        self.point_combo = QgsMapLayerComboBox()
        self.point_combo.setFilters(QgsMapLayerProxyModel.PointLayer)
        layout.addWidget(self.point_combo)

        layout.addWidget(QLabel("เลือก Layer (POLYGON):"))
        self.poly_combo = QgsMapLayerComboBox()
        self.poly_combo.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        layout.addWidget(self.poly_combo)

        layout.addWidget(QLabel("ค่าที่ต้องการค้นหา (PATH):"))
        self.search_input = QLineEdit()
        layout.addWidget(self.search_input)

        # ส่วนที่ 2: ปุ่มแก้ไข Attribute (BND_NAME) - เพิ่มใหม่ตามสั่ง
        self.btn_edit_attr = QPushButton("แก้ไข ชื่อหมุดหลักเขต")
        self.btn_edit_attr.setStyleSheet("background-color: #ffc107; color: black; margin-top: 15px;")
        self.btn_edit_attr.clicked.connect(self.activate_edit_tool)
        layout.addWidget(self.btn_edit_attr)

        # ส่วนที่ 3: ปุ่ม Filter และ Zoom
        self.btn_filter = QPushButton("เริ่ม Filter ข้อมูล (และ Zoom)")
        self.btn_filter.setStyleSheet("background-color: #007bff; color: white;")
        self.btn_filter.clicked.connect(self.apply_filter_and_zoom)
        layout.addWidget(self.btn_filter)

        self.btn_clear = QPushButton("แสดงข้อมูลทั้งหมด (Clear)")
        self.btn_clear.setStyleSheet("background-color: #6c757d; color: white;")
        self.btn_clear.clicked.connect(self.clear_filter)
        layout.addWidget(self.btn_clear)

        self.setLayout(layout)

    def activate_edit_tool(self):
        layer = self.point_combo.currentLayer()
        if not layer:
            QMessageBox.warning(self, "แจ้งเตือน", "กรุณาเลือก Layer Point ก่อน")
            return
        
        # ตรวจสอบว่ามีคอลัมน์ BND_NAME หรือไม่
        if layer.fields().indexFromName('BND_NAME') == -1:
            QMessageBox.critical(self, "Error", "ไม่พบคอลัมน์ 'BND_NAME' ใน Layer นี้")
            return

        # เปิด Map Tool สำหรับคลิกเลือกบน Canvas
        self.tool = PointSelectTool(self.iface.mapCanvas(), layer, self)
        self.iface.mapCanvas().setMapTool(self.tool)
        QMessageBox.information(self, "วิธีใช้งาน", "กรุณาคลิกเลือกหมุดบนแผนที่ที่ต้องการแก้ไข")

    def apply_filter_and_zoom(self):
        search_val = self.search_input.text().strip()
        if not search_val: return

        query = f"\"PATH\" = '{search_val}'"
        layers_to_zoom = []

        for combo in [self.point_combo, self.poly_combo]:
            layer = combo.currentLayer()
            if layer:
                layer.setSubsetString(query)
                if layer.featureCount() > 0:
                    layers_to_zoom.append(layer)

        # Zoom to Layer ที่มีข้อมูลหลัง Filter
        if layers_to_zoom:
            canvas = self.iface.mapCanvas()
            combined_extent = QgsRectangle()
            combined_extent.setToNull()
            
            for layer in layers_to_zoom:
                combined_extent.combineExtentWith(layer.extent())
            
            canvas.setExtent(combined_extent)
            canvas.refresh()

    def clear_filter(self):
        for combo in [self.point_combo, self.poly_combo]:
            layer = combo.currentLayer()
            if layer: layer.setSubsetString("")

# --- 4. Class Plugin หลัก ---
class PathFilterPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        self.action = QAction(QIcon(icon_path), "PATH Filter & Editor", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToVectorMenu("Land Dept Tools", self.action)

    def unload(self):
        self.iface.removePluginVectorMenu("Land Dept Tools", self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        self.dlg = PathFilterTool(self.iface, self.iface.mainWindow())
        self.dlg.show()