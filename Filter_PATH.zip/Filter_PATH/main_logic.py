import os
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (QAction, QDialog, QVBoxLayout, QLabel, 
                                 QLineEdit, QPushButton, QMessageBox)
from qgis.gui import QgsMapLayerComboBox, QgsMapToolEmitPoint
from qgis.core import QgsMapLayerProxyModel, QgsRectangle, QgsFeatureRequest, QgsPointXY

# --- 1. หน้าต่างสำหรับการกรอกชื่อหมุดหลักเขตใหม่ ---
class EditBndNameDialog(QDialog):
    def __init__(self, layer, features, parent=None):
        super(EditBndNameDialog, self).__init__(parent)
        self.setWindowTitle("บันทึกชื่อหมุดหลักเขตใหม่")
        self.setMinimumWidth(350)
        self.layer = layer
        self.features = features
        
        self.setStyleSheet("""
            QDialog { background-color: #f8f9fa; }
            QLabel { font-size: 12pt; font-weight: bold; color: #333; }
            QLineEdit { font-size: 14pt; padding: 8px; border: 1px solid #ced4da; border-radius: 4px; }
            QPushButton { font-size: 12pt; font-weight: bold; padding: 10px; background-color: #28a745; color: white; border-radius: 5px; }
            QPushButton:hover { background-color: #218838; }
        """)

        layout = QVBoxLayout()
        layout.addWidget(QLabel(f"กำลังแก้ไขหมุดหลักเขตจำนวน {len(features)} จุด"))
        
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("กรอกชื่อ BND_NAME ที่ถูกต้อง...")
        layout.addWidget(self.name_input)
        
        self.btn_save = QPushButton("Save (บันทึกข้อมูล)")
        self.btn_save.clicked.connect(self.save_data)
        layout.addWidget(self.btn_save)
        
        self.setLayout(layout)

    def save_data(self):
        new_name = self.name_input.text().strip()
        if not new_name:
            QMessageBox.warning(self, "แจ้งเตือน", "กรุณากรอกชื่อหมุดหลักเขต")
            return

        idx = self.layer.fields().indexOf("BND_NAME")
        if idx == -1:
            QMessageBox.critical(self, "ข้อผิดพลาด", "ไม่พบคอลัมน์ 'BND_NAME' ใน Layer นี้")
            return

        # ตรวจสอบและเปิดโหมดแก้ไขหากยังไม่ได้เปิด
        if not self.layer.isEditable():
            self.layer.startEditing()
            
        # วนลูปอัปเดตข้อมูลทุกจุดที่เลือกติดมา
        for f in self.features:
            self.layer.changeAttributeValue(f.id(), idx, new_name)
            
        # เซฟและปิดโหมดแก้ไข
        self.layer.commitChanges()
        
        QMessageBox.information(self, "สำเร็จ", "บันทึกชื่อหมุดหลักเขตเรียบร้อยแล้ว")
        self.accept()

# --- 2. เครื่องมือเมาส์สำหรับคลิกเลือกหมุดบนแผนที่ ---
class PointSelectTool(QgsMapToolEmitPoint):
    def __init__(self, canvas, layer, parent_dialog):
        super(PointSelectTool, self).__init__(canvas)
        self.canvas = canvas
        self.layer = layer
        self.parent_dialog = parent_dialog
        self.setCursor(Qt.CrossCursor) # เปลี่ยนเมาส์เป็นกากบาท

    def canvasReleaseEvent(self, e):
        # แก้ Error 2: แปลงพิกัดหน้าจอ (e.pos()) เป็นพิกัดแผนที่ (QgsPointXY)
        point = self.toMapCoordinates(e.pos())
        
        # สร้างกล่องค้นหาขนาดเล็ก (Tolerance) รอบจุดที่คลิก
        tol = self.canvas.mapUnitsPerPixel() * 5
        rect = QgsRectangle(point.x() - tol, point.y() - tol, point.x() + tol, point.y() + tol)
        
        request = QgsFeatureRequest().setFilterRect(rect)
        features = [f for f in self.layer.getFeatures(request)]
        
        if features:
            dlg = EditBndNameDialog(self.layer, features, self.parent_dialog)
            dlg.exec_()
        else:
            self.parent_dialog.iface.messageBar().pushMessage("แจ้งเตือน", "ไม่พบหมุดหลักเขตบริเวณที่คลิก โปรแกรมยังอยู่ในโหมดพร้อมเลือก", level=1, duration=3)

# --- 3. หน้าต่างเครื่องมือหลัก ---
class PathFilterTool(QDialog):
    def __init__(self, iface, parent=None):
        super(PathFilterTool, self).__init__(parent)
        self.iface = iface
        self.setWindowTitle("PATH Filter & Edit Tool")
        self.setMinimumWidth(500)
        
        self.setStyleSheet("""
            QDialog { background-color: #f5f5f5; }
            QLabel { font-size: 14pt; font-weight: bold; color: #333; margin-top: 10px; }
            QLineEdit { font-size: 16pt; padding: 10px; border: 2px solid #ccc; border-radius: 5px; }
            QComboBox { font-size: 14pt; padding: 8px; min-height: 40px; }
            QPushButton { font-size: 14pt; font-weight: bold; padding: 12px; border-radius: 6px; }
        """)

        layout = QVBoxLayout()

        layout.addWidget(QLabel("1. ระบุค่าที่ต้องการค้นหา (PATH):"))
        self.search_input = QLineEdit()
        layout.addWidget(self.search_input)

        layout.addWidget(QLabel("2. เลือก Layer (POINT):"))
        self.point_combo = QgsMapLayerComboBox()
        self.point_combo.setFilters(QgsMapLayerProxyModel.PointLayer)
        layout.addWidget(self.point_combo)

        layout.addWidget(QLabel("3. เลือก Layer (POLYGON):"))
        self.poly_combo = QgsMapLayerComboBox()
        self.poly_combo.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        layout.addWidget(self.poly_combo)

        self.btn_filter = QPushButton("เริ่ม Filter ข้อมูล")
        self.btn_filter.setStyleSheet("background-color: #007bff; color: white; margin-top: 20px;")
        self.btn_filter.clicked.connect(self.apply_filter_and_zoom)
        layout.addWidget(self.btn_filter)

        self.btn_edit_point = QPushButton("แก้ไข ชื่อหมุดหลักเขต")
        self.btn_edit_point.setStyleSheet("background-color: #ffc107; color: black;")
        self.btn_edit_point.clicked.connect(self.activate_edit_tool)
        layout.addWidget(self.btn_edit_point)

        self.btn_clear = QPushButton("แสดงข้อมูลทั้งหมด (Clear)")
        self.btn_clear.setStyleSheet("background-color: #6c757d; color: white; margin-top: 20px;")
        self.btn_clear.clicked.connect(self.clear_filter)
        layout.addWidget(self.btn_clear)

        self.setLayout(layout)

    def apply_filter_and_zoom(self):
        search_val = self.search_input.text().strip()
        point_layer = self.point_combo.currentLayer()
        poly_layer = self.poly_combo.currentLayer()

        if not search_val:
            return

        query = f"\"PATH\" = '{search_val}'"
        
        combined_extent = QgsRectangle()
        combined_extent.setMinimal() # แก้ Error 1: เปลี่ยนจาก setToNull() เป็น setMinimal()
        has_data = False
        
        for layer in [point_layer, poly_layer]:
            if layer:
                layer.setSubsetString(query)
                layer.updateExtents()
                ext = layer.extent()
                if not ext.isEmpty():
                    combined_extent.combineExtentWith(ext)
                    has_data = True

        if has_data:
            canvas = self.iface.mapCanvas()
            combined_extent.scale(1.1)
            canvas.setExtent(combined_extent)
            canvas.refresh()

    def activate_edit_tool(self):
        point_layer = self.point_combo.currentLayer()
        if not point_layer:
            QMessageBox.warning(self, "แจ้งเตือน", "กรุณาเลือก Layer POINT ก่อนใช้งานเครื่องมือนี้")
            return
            
        # สั่งเปิด Edit Mode ทันที
        if not point_layer.isEditable():
            point_layer.startEditing()
            self.iface.messageBar().pushMessage("สถานะ", f"เปิดโหมดแก้ไขสำหรับ Layer: {point_layer.name()}", level=0, duration=3)
            
        canvas = self.iface.mapCanvas()
        tool = PointSelectTool(canvas, point_layer, self)
        canvas.setMapTool(tool)
        self.iface.messageBar().pushMessage("คำแนะนำ", "นำเมาส์ไปคลิกที่หมุดบนแผนที่ เพื่อแก้ไข BND_NAME", level=0, duration=5)

    def clear_filter(self):
        for combo in [self.point_combo, self.poly_combo]:
            layer = combo.currentLayer()
            if layer:
                layer.setSubsetString("")

# --- 4. ส่วนการจัดการตัวปลั๊กอิน ---
class PathFilterPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        self.action = QAction(icon, "Path Filter & Edit Tool", self.iface.mainWindow())
        self.action.triggered.connect(self.run)

        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToVectorMenu("Land Dept Tools", self.action)

    def unload(self):
        self.iface.removePluginVectorMenu("Land Dept Tools", self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        self.dlg = PathFilterTool(self.iface, self.iface.mainWindow())
        self.dlg.show()