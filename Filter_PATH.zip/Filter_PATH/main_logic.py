import os
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox
from qgis.gui import QgsMapLayerComboBox
from qgis.core import QgsMapLayerProxyModel, QgsProject

class PathFilterTool(QDialog):
    def __init__(self, iface, parent=None):
        super(PathFilterTool, self).__init__(parent)
        self.iface = iface
        self.setWindowTitle("PATH Filter & Editor - DOL")
        self.setMinimumWidth(500)
        
        # UI Styling (Large Font)
        self.setStyleSheet("""
            QDialog { background-color: #f8f9fa; }
            QLabel { font-size: 13pt; font-weight: bold; color: #2c3e50; margin-top: 8px; }
            QLineEdit { font-size: 15pt; padding: 10px; border: 2px solid #bdc3c7; border-radius: 5px; }
            QComboBox { font-size: 13pt; padding: 5px; min-height: 40px; }
            QPushButton { font-size: 13pt; font-weight: bold; padding: 12px; border-radius: 6px; margin-top: 5px; }
        """)

        layout = QVBoxLayout()

        # 1. Search Box
        layout.addWidget(QLabel("1. ระบุค่า PATH / ชื่อที่ต้องการ:"))
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("ใส่ค่าที่ต้องการค้นหาหรือแก้ไขที่นี่...")
        layout.addWidget(self.search_input)

        # 2. Layer Selection
        layout.addWidget(QLabel("2. เลือก Layer POINT:"))
        self.point_combo = QgsMapLayerComboBox()
        self.point_combo.setFilters(QgsMapLayerProxyModel.PointLayer)
        layout.addWidget(self.point_combo)

        layout.addWidget(QLabel("3. เลือก Layer POLYGON:"))
        self.poly_combo = QgsMapLayerComboBox()
        self.poly_combo.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        layout.addWidget(self.poly_combo)

        # --- เพิ่มปุ่มแก้ไข BND_NAME (ข้อ 1 & 2) ---
        self.btn_edit_bnd = QPushButton("📝 แก้ไข ชื่อหมุดหลักเขต (BND_NAME)")
        self.btn_edit_bnd.setStyleSheet("background-color: #f39c12; color: white; margin-top: 15px;")
        self.btn_edit_bnd.clicked.connect(self.edit_bnd_name)
        layout.addWidget(self.btn_edit_bnd)

        # 4. Filter Button (พร้อม Zoom)
        self.btn_filter = QPushButton("🔍 เริ่ม Filter ข้อมูล และ Zoom")
        self.btn_filter.setStyleSheet("background-color: #2980b9; color: white;")
        self.btn_filter.clicked.connect(self.apply_filter_and_zoom)
        layout.addWidget(self.btn_filter)

        # 5. Clear Button
        self.btn_clear = QPushButton("แสดงข้อมูลทั้งหมด (Clear)")
        self.btn_clear.setStyleSheet("background-color: #95a5a6; color: white;")
        self.btn_clear.clicked.connect(self.clear_filter)
        layout.addWidget(self.btn_clear)

        self.setLayout(layout)

    def edit_bnd_name(self):
        """ฟังก์ชันแก้ไข Attribute BND_NAME ใน Layer Point"""
        layer = self.point_combo.currentLayer()
        new_val = self.search_input.text().strip()

        if not layer or not new_val:
            QMessageBox.warning(self, "แจ้งเตือน", "กรุณาเลือก Layer และระบุชื่อที่ต้องการแก้ไข")
            return

        # ตรวจสอบว่ามีคอลัมน์ BND_NAME หรือไม่
        field_index = layer.fields().indexOf("BND_NAME")
        if field_index == -1:
            QMessageBox.critical(self, "Error", "ไม่พบชื่อคอลัมน์ 'BND_NAME' ใน Layer นี้")
            return

        # เริ่มการแก้ไข (Edit Session)
        layer.startEditing()
        count = 0
        for feature in layer.getFeatures(): # วนลูปเฉพาะข้อมูลที่ผ่านการ Filter (ถ้ามีการ Filter อยู่)
            layer.changeAttributeValue(feature.id(), field_index, new_val)
            count += 1
        
        reply = QMessageBox.question(self, "ยืนยันการแก้ไข", 
                                   f"ต้องการเปลี่ยน BND_NAME เป็น '{new_val}' ทั้งหมด {count} รายการ ใช่หรือไม่?",
                                   QMessageBox.Yes | QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            layer.commitChanges()
            QMessageBox.information(self, "สำเร็จ", "แก้ไขข้อมูลเรียบร้อยแล้ว")
        else:
            layer.rollBack()

    def apply_filter_and_zoom(self):
        """ฟังก์ชัน Filter และ Zoom (ข้อ 3)"""
        search_val = self.search_input.text().strip()
        point_layer = self.point_combo.currentLayer()
        poly_layer = self.poly_combo.currentLayer()

        if not search_val: return

        query = f"\"PATH\" = '{search_val}'"
        
        target_layer = None
        for layer in [point_layer, poly_layer]:
            if layer:
                layer.setSubsetString(query)
                if layer.featureCount() > 0:
                    target_layer = layer # เก็บ Layer ที่มีข้อมูลไว้ Zoom

        # Zoom to Layer
        if target_layer:
            self.iface.mapCanvas().setExtent(target_layer.extent())
            self.iface.mapCanvas().refresh()
        else:
            QMessageBox.information(self, "ไม่พบข้อมูล", f"ไม่พบข้อมูลที่มี PATH = {search_val}")

    def clear_filter(self):
        for combo in [self.point_combo, self.poly_combo]:
            layer = combo.currentLayer()
            if layer: layer.setSubsetString("")
        self.iface.mapCanvas().zoomToFullExtent()

class PathFilterPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        self.action = QAction(QIcon(icon_path), "Path Filter & Editor", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToVectorMenu("DOL Tools", self.action)

    def unload(self):
        self.iface.removePluginVectorMenu("DOL Tools", self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        self.dlg = PathFilterTool(self.iface, self.iface.mainWindow())
        self.dlg.show()