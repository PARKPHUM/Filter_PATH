import os
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (QAction, QDialog, QVBoxLayout, QLabel, 
                                 QLineEdit, QPushButton, QMessageBox, QFormLayout, QGroupBox)
from qgis.gui import QgsMapLayerComboBox, QgsMapToolEmitPoint
from qgis.core import QgsMapLayerProxyModel, QgsRectangle, QgsFeatureRequest, QgsSettings

# --- 1. หน้าต่างสำหรับการกรอกชื่อหมุดหลักเขตใหม่ (POINT) ---
class EditBndNameDialog(QDialog):
    def __init__(self, layer, features, parent=None):
        super(EditBndNameDialog, self).__init__(parent)
        self.setWindowTitle("บันทึกชื่อหมุดหลักเขตใหม่")
        self.setMinimumWidth(350)
        self.layer = layer
        self.features = features
        
        self.setStyleSheet("""
            QLabel { font-size: 12pt; font-weight: bold; }
            QLineEdit { font-size: 14pt; padding: 5px; }
            QPushButton { font-size: 12pt; font-weight: bold; padding: 8px; background-color: #28a745; color: white; border-radius: 5px; }
        """)

        layout = QVBoxLayout()
        layout.addWidget(QLabel(f"แก้ไขข้อมูลหมุดจำนวน {len(features)} จุด"))
        
        self.name_input = QLineEdit()
        
        # ดึงค่าเก่ามาแสดง (ถ้ามี)
        idx = self.layer.fields().indexOf("BND_NAME")
        if idx != -1 and len(self.features) > 0:
            current_val = self.features[0].attribute(idx)
            if current_val:
                self.name_input.setText(str(current_val))
                
        self.name_input.setPlaceholderText("ระบุชื่อ BND_NAME ใหม่...")
        layout.addWidget(self.name_input)
        
        self.btn_save = QPushButton("Save (บันทึก)")
        self.btn_save.clicked.connect(self.save_data)
        layout.addWidget(self.btn_save)
        
        self.setLayout(layout)

    def save_data(self):
        new_name = self.name_input.text().strip()
        idx = self.layer.fields().indexOf("BND_NAME")
        if idx == -1:
            QMessageBox.critical(self, "ข้อผิดพลาด", "ไม่พบคอลัมน์ 'BND_NAME'")
            return

        for f in self.features:
            self.layer.changeAttributeValue(f.id(), idx, new_name)
        
        QMessageBox.information(self, "สำเร็จ", "อัปเดตชื่อหมุดหลักเขตเรียบร้อยแล้ว")
        self.accept()

# --- 2. หน้าต่างสำหรับแก้ไข Attribute หลายฟิลด์ (UTM & LANDNO) ---
class EditAttributesDialog(QDialog):
    def __init__(self, point_layer, poly_layer, parent=None):
        super(EditAttributesDialog, self).__init__(parent)
        self.setWindowTitle("แก้ไข Attribute (UTM & LANDNO)")
        self.setMinimumWidth(450)
        self.point_layer = point_layer
        self.poly_layer = poly_layer
        
        self.fields_to_edit = ["UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMSCALE", "UTMMAP4", "LANDNO"]
        self.inputs = {}

        self.setStyleSheet("""
            QLabel { font-size: 11pt; font-weight: bold; }
            QLineEdit { font-size: 12pt; padding: 5px; }
            QPushButton { font-size: 12pt; font-weight: bold; padding: 10px; background-color: #17a2b8; color: white; border-radius: 5px; }
        """)

        main_layout = QVBoxLayout()
        form_group = QGroupBox("ระบุข้อมูลที่ต้องการแก้ไขลงทั้ง Point และ Polygon")
        form_layout = QFormLayout()

        # พยายามดึงค่าตัวอย่างจาก Polygon มาแสดง
        sample_feature = None
        if self.poly_layer:
            for f in self.poly_layer.getFeatures():
                sample_feature = f
                break

        for field in self.fields_to_edit:
            line_edit = QLineEdit()
            if sample_feature:
                idx = self.poly_layer.fields().indexOf(field)
                if idx != -1:
                    val = sample_feature.attribute(idx)
                    if val: line_edit.setText(str(val))
            
            self.inputs[field] = line_edit
            form_layout.addRow(QLabel(field + ":"), line_edit)

        form_group.setLayout(form_layout)
        main_layout.addWidget(form_group)

        self.btn_save = QPushButton("บันทึกการแก้ไขทั้งหมด")
        self.btn_save.clicked.connect(self.save_attributes)
        main_layout.addWidget(self.btn_save)

        self.setLayout(main_layout)

    def save_attributes(self):
        layers = [l for l in [self.point_layer, self.poly_layer] if l is not None]
        for layer in layers:
            if not layer.isEditable():
                layer.startEditing()
            for field, input_box in self.inputs.items():
                val = input_box.text().strip()
                idx = layer.fields().indexOf(field)
                if idx != -1 and val:
                    for f in layer.getFeatures():
                        layer.changeAttributeValue(f.id(), idx, val)
        
        QMessageBox.information(self, "สำเร็จ", "อัปเดตข้อมูล UTM และ LANDNO เรียบร้อยแล้ว")
        self.accept()

# --- 3. เครื่องมือเมาส์สำหรับคลิกเลือกหมุดบนแผนที่ ---
class PointSelectTool(QgsMapToolEmitPoint):
    def __init__(self, canvas, layer, parent_dialog):
        super(PointSelectTool, self).__init__(canvas)
        self.canvas = canvas
        self.layer = layer
        self.parent_dialog = parent_dialog
        self.setCursor(Qt.CrossCursor)

    def canvasReleaseEvent(self, e):
        point = self.toMapCoordinates(e.pos())
        tol = self.canvas.mapUnitsPerPixel() * 10
        rect = QgsRectangle(point.x() - tol, point.y() - tol, point.x() + tol, point.y() + tol)
        
        request = QgsFeatureRequest().setFilterRect(rect)
        features = [f for f in self.layer.getFeatures(request)]
        
        if features:
            dlg = EditBndNameDialog(self.layer, features, self.parent_dialog)
            dlg.exec_()
        else:
            self.parent_dialog.iface.messageBar().pushMessage("แจ้งเตือน", "ไม่พบหมุดบริเวณที่คลิก", level=1)
        self.canvas.unsetMapTool(self)

# --- 4. หน้าต่างเครื่องมือหลัก ---
class PathFilterTool(QDialog):
    def __init__(self, iface, parent=None):
        super(PathFilterTool, self).__init__(parent)
        self.iface = iface
        self.edit_tool = None 
        self.setWindowTitle("PATH Filter & Edit Tool")
        self.setMinimumWidth(500)
        
        self.setStyleSheet("""
            QDialog { background-color: #f8f9fa; }
            QLabel { font-size: 14pt; font-weight: bold; color: #333; margin-top: 10px; }
            QLineEdit { font-size: 16pt; padding: 10px; border: 2px solid #ccc; border-radius: 5px; }
            QComboBox { font-size: 14pt; padding: 8px; min-height: 40px; }
            QPushButton { font-size: 14pt; font-weight: bold; padding: 12px; border-radius: 6px; }
        """)

        layout = QVBoxLayout()

        layout.addWidget(QLabel("1. ระบุค่าที่ต้องการค้นหา (PATH):"))
        self.search_input = QLineEdit()
        layout.addWidget(self.search_input)

        layout.addWidget(QLabel("2. เลือก Layer (POINT):"))
        self.point_combo = QgsMapLayerComboBox()
        self.point_combo.setFilters(QgsMapLayerProxyModel.PointLayer)
        layout.addWidget(self.point_combo)

        layout.addWidget(QLabel("3. เลือก Layer (POLYGON):"))
        self.poly_combo = QgsMapLayerComboBox()
        self.poly_combo.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        layout.addWidget(self.poly_combo)

        self.btn_filter = QPushButton("เริ่ม Filter ข้อมูล (ซูมอัตโนมัติ)")
        self.btn_filter.setStyleSheet("background-color: #007bff; color: white; margin-top: 15px;")
        self.btn_filter.clicked.connect(self.apply_filter_and_zoom)
        layout.addWidget(self.btn_filter)

        self.btn_edit_point = QPushButton("แก้ไข ชื่อหมุดหลักเขต")
        self.btn_edit_point.setStyleSheet("background-color: #ffc107; color: black;")
        self.btn_edit_point.clicked.connect(self.activate_edit_point_tool)
        layout.addWidget(self.btn_edit_point)

        self.btn_edit_attr = QPushButton("แก้ไข Attribute (UTM & LANDNO)")
        self.btn_edit_attr.setStyleSheet("background-color: #17a2b8; color: white;")
        self.btn_edit_attr.clicked.connect(self.open_edit_attributes)
        layout.addWidget(self.btn_edit_attr)

        self.btn_clear = QPushButton("แสดงข้อมูลทั้งหมด (Clear)")
        self.btn_clear.setStyleSheet("background-color: #6c757d; color: white; margin-top: 15px;")
        self.btn_clear.clicked.connect(self.clear_filter)
        layout.addWidget(self.btn_clear)

        # ---------------------------------------------
        # เพิ่มปุ่มสำหรับเช็คอัปเดตใหม่ (สีเขียว)
        # ---------------------------------------------
        self.btn_update = QPushButton("ตรวจสอบอัปเดตปลั๊กอิน (Check for Updates)")
        self.btn_update.setStyleSheet("background-color: #28a745; color: white; margin-top: 15px;")
        self.btn_update.clicked.connect(self.check_for_updates)
        layout.addWidget(self.btn_update)

        self.setLayout(layout)

    # ฟังก์ชันเรียกการตรวจสอบอัปเดต
    def check_for_updates(self):
        settings = QgsSettings()
        repo_name = "Land_Dept_Tools"
        base_path = f"plugins/searchRepositories/{repo_name}"

        # 1. เขียนค่า URL ลงใน Setting ของ QGIS ทันที (มีการเพิ่ม authcfg ป้องกัน Error)
        settings.setValue(f"{base_path}/url", "https://raw.githubusercontent.com/PARKPHUM/Filter_PATH/main/plugins.xml")
        settings.setValue(f"{base_path}/enabled", True)
        settings.setValue(f"{base_path}/authcfg", "")

        # 2. เด้งข้อความแจ้งเตือนผู้ใช้
        msg = ("บันทึกลิงก์อัปเดตเข้าสู่ระบบเรียบร้อยแล้ว!\n\n"
               "ระบบกำลังเปิดหน้าต่าง Plugins ให้คุณ...\n"
               "1. เลือกแท็บ 'Settings' แล้วกดปุ่ม 'Check for updates now'\n"
               "2. หากมีเวอร์ชันใหม่ ให้ไปที่แท็บ 'Upgradeable' แล้วกดอัปเดตได้เลย")
        QMessageBox.information(self, "แจ้งเตือนการอัปเดต", msg)

        # 3. สั่งเปิดหน้าต่าง Plugin Manager ของ QGIS ขึ้นมาให้โดยอัตโนมัติ
        if self.iface.pluginManagerInterface():
            self.iface.pluginManagerInterface().showPluginManager()

    def apply_filter_and_zoom(self):
        val = self.search_input.text().strip()
        p_layer = self.point_combo.currentLayer()
        poly_layer = self.poly_combo.currentLayer()
        if not val: return

        combined_extent = QgsRectangle()
        combined_extent.setMinimal() 
        has_data = False
        
        for layer in [p_layer, poly_layer]:
            if layer:
                layer.setSubsetString(f"\"PATH\" = '{val}'")
                layer.updateExtents()
                if not layer.extent().isEmpty():
                    combined_extent.combineExtentWith(layer.extent())
                    has_data = True

        if has_data:
            canvas = self.iface.mapCanvas()
            combined_extent.scale(1.1)
            canvas.setExtent(combined_extent)
            canvas.refresh()

    def activate_edit_point_tool(self):
        p_layer = self.point_combo.currentLayer()
        if not p_layer: return
        if not p_layer.isEditable(): p_layer.startEditing()
        
        canvas = self.iface.mapCanvas()
        self.edit_tool = PointSelectTool(canvas, p_layer, self)
        canvas.setMapTool(self.edit_tool)
        self.iface.messageBar().pushMessage("แจ้ง", "คลิกที่หมุดบนแผนที่เพื่อแก้ไข", level=0)

    def open_edit_attributes(self):
        p_layer = self.point_combo.currentLayer()
        poly_layer = self.poly_combo.currentLayer()
        if p_layer or poly_layer:
            dlg = EditAttributesDialog(p_layer, poly_layer, self)
            dlg.exec_()

    def clear_filter(self):
        for combo in [self.point_combo, self.poly_combo]:
            l = combo.currentLayer()
            if l: l.setSubsetString(""); l.updateExtents()

# --- 5. ส่วนการจัดการตัวปลั๊กอิน ---
class PathFilterPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        self.action = QAction(icon, "Path Filter & Edit Tool", self.iface.mainWindow())
        self.action.triggered.connect(self.run)

        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToVectorMenu("Land Dept Tools", self.action)

    def unload(self):
        self.iface.removePluginVectorMenu("Land Dept Tools", self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        self.dlg = PathFilterTool(self.iface, self.iface.mainWindow())
        self.dlg.show()